"""
Scheduler — rule-based orchestrator for the compliance pipeline.

Flow: ParserMatcher → ConsistencyChecker (rule engine) → RiskAssessor
      → ComplianceReviewer → Advisor

The rule engine runs automatically between ParserMatcher and RiskAssessor.
Human escalation is a first-class exit path.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Callable

from ..agents.parser_matcher import ParserMatcherAgent
from ..agents.risk_assessor import RiskAssessorAgent
from ..agents.compliance_reviewer import ComplianceReviewerAgent
from ..agents.advisor import AdvisorAgent
from ..rules.consistency import ConsistencyChecker
from ..state.contract_state import ContractState, Stage, ReviewDecision

logger = logging.getLogger(__name__)


class Action(str, Enum):
    RUN_PARSER_MATCHER = "run_parser_matcher"
    RUN_CONSISTENCY_CHECK = "run_consistency_check"
    RUN_RISK_ASSESSOR = "run_risk_assessor"
    RUN_REVIEWER = "run_reviewer"
    RUN_ADVISOR = "run_advisor"
    DONE = "done"
    FAILED = "failed"
    ESCALATED = "escalated"


@dataclass
class SchedulerResult:
    state: ContractState
    success: bool
    escalated: bool
    message: str
    total_versions: int
    rollbacks_used: int


class Scheduler:

    def __init__(
        self,
        parser_matcher: ParserMatcherAgent,
        risk_assessor: RiskAssessorAgent,
        reviewer: ComplianceReviewerAgent,
        advisor: AdvisorAgent,
        consistency_checker: ConsistencyChecker | None = None,
    ):
        self.agents = {
            Action.RUN_PARSER_MATCHER: parser_matcher,
            Action.RUN_RISK_ASSESSOR: risk_assessor,
            Action.RUN_REVIEWER: reviewer,
            Action.RUN_ADVISOR: advisor,
        }
        self.consistency_checker = consistency_checker or ConsistencyChecker()
        self.on_step: Callable[[Action, ContractState], None] | None = None

    def _decide(self, state: ContractState) -> Action:
        v = state.latest()
        if v is None:
            return Action.RUN_PARSER_MATCHER

        stage = v.stage

        if stage == Stage.PARSING_MATCHING:
            return Action.RUN_CONSISTENCY_CHECK

        if stage == Stage.RISK_ASSESSMENT:
            return Action.RUN_REVIEWER

        if stage == Stage.COMPLIANCE_REVIEW:
            decision_str = v.metadata.get("decision", "fix_and_retry")
            try:
                decision = ReviewDecision(decision_str)
            except ValueError:
                decision = ReviewDecision.FIX_AND_RETRY

            if decision == ReviewDecision.PASS:
                return Action.RUN_ADVISOR

            if decision == ReviewDecision.FIX_AND_RETRY:
                return Action.RUN_PARSER_MATCHER

            if decision == ReviewDecision.ESCALATE_TO_HUMAN:
                return Action.ESCALATED

        if stage == Stage.ADVISORY:
            return Action.DONE

        return Action.FAILED

    def _find_parser_version(self, state: ContractState) -> int | None:
        for v in reversed(state.versions):
            if v.stage == Stage.PARSING_MATCHING:
                return v.version
        return None

    def run(self, state: ContractState) -> SchedulerResult:
        max_iterations = 10
        iteration = 0

        while iteration < max_iterations:
            iteration += 1
            action = self._decide(state)

            logger.info(
                "Scheduler iteration %d → action=%s  rollback=%d/%d",
                iteration, action.value, state.rollback_count, state.max_rollbacks,
            )

            # ---- Terminal states ----
            if action == Action.DONE:
                state.final_output = {
                    "status": "success",
                    "clauses": state.artifacts.clauses,
                    "compliance_results": state.artifacts.compliance_results,
                    "risk_matrix": state.artifacts.risk_matrix,
                    "review_report": state.artifacts.review_report,
                    "amendment_proposals": state.artifacts.amendment_proposals,
                }
                return SchedulerResult(
                    state=state, success=True, escalated=False,
                    message="Compliance review completed successfully.",
                    total_versions=state.current_version,
                    rollbacks_used=state.rollback_count,
                )

            if action == Action.ESCALATED:
                state.final_output = {
                    "status": "escalated",
                    "reason": state.latest().metadata.get("escalation_reason", ""),
                    "best_results": {
                        "clauses": state.artifacts.clauses,
                        "compliance_results": state.artifacts.compliance_results,
                        "risk_matrix": state.artifacts.risk_matrix,
                        "review_report": state.artifacts.review_report,
                    },
                    "human_escalations": state.human_escalations,
                }
                return SchedulerResult(
                    state=state, success=False, escalated=True,
                    message="Escalated to human review.",
                    total_versions=state.current_version,
                    rollbacks_used=state.rollback_count,
                )

            if action == Action.FAILED:
                state.final_output = {
                    "status": "failed",
                    "reason": "Pipeline failed.",
                    "best_results": {
                        "clauses": state.artifacts.clauses,
                        "risk_matrix": state.artifacts.risk_matrix,
                    },
                }
                return SchedulerResult(
                    state=state, success=False, escalated=False,
                    message="Pipeline failed.",
                    total_versions=state.current_version,
                    rollbacks_used=state.rollback_count,
                )

            # ---- Consistency check (rule engine, no LLM) ----
            if action == Action.RUN_CONSISTENCY_CHECK:
                logger.info("Running rule-based consistency check...")
                issues = self.consistency_checker.check(state.artifacts.clauses)
                # Merge consistency results into current artifacts
                v = state.latest()
                from ..state.contract_state import Artifacts
                new_artifacts = Artifacts(
                    document_text=v.artifacts.document_text,
                    clauses=v.artifacts.clauses,
                    compliance_results=v.artifacts.compliance_results,
                    consistency_results=issues,
                )
                state.add_version(
                    stage=Stage.RISK_ASSESSMENT,  # advance stage
                    agent="ConsistencyChecker",
                    artifacts=new_artifacts,
                    metadata={"consistency_issues_count": len(issues)},
                )
                if self.on_step:
                    self.on_step(action, state)
                continue

            # ---- LLM agents ----
            agent = self.agents[action]
            try:
                state = agent.run(state)
            except Exception as e:
                logger.error("Agent [%s] raised: %s", agent.name, e)
                return SchedulerResult(
                    state=state, success=False, escalated=False,
                    message=f"Agent [{agent.name}] failed: {e}",
                    total_versions=state.current_version,
                    rollbacks_used=state.rollback_count,
                )

            if self.on_step:
                self.on_step(action, state)

        return SchedulerResult(
            state=state, success=False, escalated=False,
            message=f"Exceeded max iterations ({max_iterations}).",
            total_versions=state.current_version,
            rollbacks_used=state.rollback_count,
        )
