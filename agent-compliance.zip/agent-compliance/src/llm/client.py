"""
Unified LLM client — wraps the OpenAI-compatible chat completions API.
Works with OpenAI, Anthropic (via proxy), Ollama, vLLM, LiteLLM, etc.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from openai import OpenAI

logger = logging.getLogger(__name__)


class LLMClient:

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str = "gpt-4o",
        temperature: float = 0.2,
        max_tokens: int = 8192,
    ):
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.client = OpenAI(
            api_key=api_key or os.getenv("OPENAI_API_KEY", ""),
            base_url=base_url or os.getenv("OPENAI_BASE_URL"),
        )

    def chat(self, system: str, user: str, temperature: float | None = None,
             max_tokens: int | None = None, json_mode: bool = False) -> str:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature if temperature is not None else self.temperature,
            "max_tokens": max_tokens or self.max_tokens,
        }
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}

        logger.info("LLM request → model=%s  tokens=%d", self.model, kwargs["max_tokens"])
        resp = self.client.chat.completions.create(**kwargs)
        content = resp.choices[0].message.content or ""
        logger.info("LLM response ← %d chars", len(content))
        return content

    def chat_json(self, system: str, user: str, temperature: float | None = None) -> dict[str, Any]:
        raw = self.chat(system, user, temperature=temperature, json_mode=True)
        text = raw.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)
        return json.loads(text)
