"""
Advisor Agent — generates amendment proposals and risk mitigation plans.

Only runs after the Compliance Reviewer passes. Produces:
  - Specific amendment proposals for non-compliant clauses
  - Alternative clause text with legal basis
  - Risk mitigation strategies for unresolvable risks
  - Priority-ranked action items
"""

from __future__ import annotations

from .base import BaseAgent
from ..state.contract_state import ContractState, Artifacts, Stage

SYSTEM_PROMPT = """\
You are a senior legal counsel providing amendment recommendations.
You will receive:
  1. The original contract and parsed clauses
  2. Regulation matching results (non-compliant items)
  3. Risk matrix (identified risks)
  4. Compliance review report

Your job is to produce actionable amendment proposals.

## For each non-compliant or high-risk clause, provide:
- original_clause_id: reference to the problematic clause
- issue: what is wrong
- proposed_amendment: full replacement clause text (not just a suggestion —
  actual contract-ready language)
- legal_basis: regulation citation supporting the amendment
- priority: critical | high | medium | low
- rationale: why this amendment resolves the issue

## For risks that cannot be resolved through amendment:
- Provide a risk mitigation strategy
- Explain what operational or procedural measures can reduce the risk

## Output Format
Return a JSON object:
{
  "amendment_proposals": [
    {
      "proposal_id": "A01",
      "original_clause_id": "C03",
      "issue": "违约金比例过高，可能被法院调整",
      "proposed_amendment": "如乙方违约，应向甲方支付合同总价款15%的违约金。违约金不足以弥补甲方实际损失的，乙方应当赔偿差额部分。",
      "legal_basis": "《民法典》第585条：约定的违约金过分高于造成的损失的，人民法院或者仲裁机构可以根据当事人的请求予以适当减少",
      "priority": "high",
      "rationale": "将违约金控制在15%，符合司法实践中不超过30%的一般标准"
    }
  ],
  "mitigation_strategies": [
    {
      "risk_id": "R03",
      "risk_description": "...",
      "strategy": "...",
      "implementation": "具体操作步骤"
    }
  ],
  "missing_clause_proposals": [
    {
      "clause_type": "confidentiality",
      "proposed_text": "完整的保密条款文本...",
      "reason": "合同涉及商业秘密但未设保密条款"
    }
  ],
  "action_summary": {
    "critical_actions": 2,
    "high_actions": 3,
    "medium_actions": 1,
    "total_amendments": 6,
    "estimated_effort": "2-3 hours of legal review"
  }
}
"""


class AdvisorAgent(BaseAgent):
    name = "Advisor"

    def run(self, state: ContractState) -> ContractState:
        self._log_start(state)
        artifacts = state.artifacts

        # Gather non-compliant items
        non_compliant = [
            r for r in artifacts.compliance_results
            if r.get("judgment") in ("non_compliant", "partially_compliant", "uncertain")
        ]

        nc_text = "\n".join(
            f"- [{r.get('clause_id', '?')}] {r.get('regulation', '?')}: "
            f"{r.get('judgment', '?')} — {r.get('reason', '')}"
            for r in non_compliant
        ) or "No non-compliant items found."

        risk_text = "\n".join(
            f"- [{r.get('risk_id', '?')}] ({r.get('severity', '?')}) {r.get('description', '')}"
            for r in artifacts.risk_matrix
        ) or "No risks identified."

        # Include missing clauses from risk assessor metadata
        missing = ""
        v = state.latest()
        if v and v.metadata.get("missing_clauses"):
            missing_items = v.metadata["missing_clauses"]
            missing = "\n\n## Missing Clauses\n" + "\n".join(
                f"- {m.get('suggested_clause', '?')}: {m.get('reason', '')}"
                for m in missing_items
            )

        user_prompt = (
            f"# Contract Type: {state.contract_type}\n\n"
            f"# Non-Compliant Items\n\n{nc_text}\n\n"
            f"# Risk Matrix\n\n{risk_text}\n\n"
            f"# Compliance Review\n\n{artifacts.review_report}\n"
            f"{missing}\n\n"
            "Please produce amendment proposals and risk mitigation strategies."
        )

        result = self.llm.chat_json(SYSTEM_PROMPT, user_prompt)

        new_artifacts = Artifacts(
            document_text=artifacts.document_text,
            clauses=artifacts.clauses,
            compliance_results=artifacts.compliance_results,
            consistency_results=artifacts.consistency_results,
            risk_matrix=artifacts.risk_matrix,
            review_report=artifacts.review_report,
            amendment_proposals=result.get("amendment_proposals", []),
        )

        state.add_version(
            stage=Stage.ADVISORY,
            agent=self.name,
            artifacts=new_artifacts,
            metadata={
                "mitigation_strategies": result.get("mitigation_strategies", []),
                "missing_clause_proposals": result.get("missing_clause_proposals", []),
                "action_summary": result.get("action_summary", {}),
            },
        )

        self._log_done(state)
        return state
