"""
Parser + Matcher Agent — combined clause parsing and regulation matching.

This agent does two things in a single pass:
  1. Parse the contract into structured clauses
  2. Match each clause against applicable regulations

Combining them allows the regulation knowledge to inform clause extraction
(e.g., recognising a clause type by its legal terminology).
"""

from __future__ import annotations

from .base import BaseAgent
from ..state.contract_state import ContractState, Artifacts, Stage

SYSTEM_PROMPT = """\
You are a senior legal analyst specialising in Chinese contract law.
Your job is to parse a contract document and match each clause to applicable regulations.

## Step 1: Clause Parsing
For each clause in the contract, extract:
- clause_id: sequential identifier (C01, C02, ...)
- clause_type: one of [payment, price, confidentiality, liability, penalty,
  liquidated_damages, termination, warranty, guarantee, duration, term,
  dispute_resolution, force_majeure, ip_ownership, non_compete, assignment,
  governing_law, definitions, other]
- parties: list of party names mentioned
- content: the full clause text
- amount: monetary amount if any (with currency)
- date: key dates mentioned
- obligations: list of obligations described
- dependencies: IDs of clauses this clause references

Handle "但是" (but/proviso) clauses by splitting into main rule + exception,
linked via dependencies.

## Step 2: Regulation Matching
For each clause, identify the most relevant regulation articles. For each match:
- regulation: full citation (e.g. "《民法典》第585条")
- judgment: one of [compliant, non_compliant, partially_compliant, uncertain, not_applicable]
- confidence: one of [high, medium, low]
- reason: why this judgment was made
- regulation_text: brief excerpt of the matched regulation

If the regulation scope is provided, match against those regulations first.
If no regulation applies, set judgment to "not_applicable".

## Output Format
Return a JSON object:
{
  "clauses": [
    {
      "clause_id": "C01",
      "clause_type": "payment",
      "parties": ["甲方", "乙方"],
      "content": "...",
      "amount": "100000元",
      "date": "2026-06-01",
      "obligations": ["甲方应于合同签订后30日内支付全款"],
      "dependencies": ["C05"]
    }
  ],
  "compliance_results": [
    {
      "clause_id": "C01",
      "regulation": "《民法典》第509条",
      "judgment": "compliant",
      "confidence": "high",
      "reason": "合同约定的付款方式符合全面履行原则",
      "regulation_text": "当事人应当按照约定全面履行自己的义务..."
    }
  ],
  "contract_type": "sales|labour|service|lease|technology|other",
  "parties_identified": ["甲方: XX公司", "乙方: YY公司"],
  "parsing_notes": "any observations about document quality or ambiguity"
}
"""


class ParserMatcherAgent(BaseAgent):
    name = "ParserMatcher"

    def run(self, state: ContractState) -> ContractState:
        self._log_start(state)

        doc_text = state.artifacts.document_text
        if not doc_text:
            raise ValueError("No document text found in state.")

        # Build regulation context
        reg_context = ""
        if state.regulation_scope:
            reg_context = (
                "\n\n## Applicable Regulations\n"
                "Focus your matching on the following regulations:\n"
                + "\n".join(f"- {r}" for r in state.regulation_scope)
            )

        # If rolling back, include reviewer feedback
        feedback = ""
        v = state.latest()
        if v and v.metadata.get("fix_instructions"):
            feedback = (
                f"\n\n## Fix Instructions from Reviewer\n"
                f"{v.metadata['fix_instructions']}\n"
                "Please address these issues in your revised analysis."
            )

        user_prompt = (
            f"# Contract Document\n\n{doc_text}\n"
            f"{reg_context}\n{feedback}\n\n"
            "Please parse the contract and match each clause to applicable regulations."
        )

        result = self.llm.chat_json(SYSTEM_PROMPT, user_prompt)

        artifacts = Artifacts(
            document_text=doc_text,
            clauses=result.get("clauses", []),
            compliance_results=result.get("compliance_results", []),
        )

        state.add_version(
            stage=Stage.PARSING_MATCHING,
            agent=self.name,
            artifacts=artifacts,
            metadata={
                "contract_type": result.get("contract_type", "other"),
                "parties": result.get("parties_identified", []),
                "parsing_notes": result.get("parsing_notes", ""),
            },
        )

        # Update contract type on state
        state.contract_type = result.get("contract_type", "other")

        self._log_done(state)
        return state
