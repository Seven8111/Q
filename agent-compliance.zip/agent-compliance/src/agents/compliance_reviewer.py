"""
Compliance Reviewer Agent — quality gate for the entire pipeline.

Reviews the completeness and consistency of all prior outputs, then
makes a routing decision:
  - pass              → proceed to Advisor
  - fix_and_retry     → back to ParserMatcher
  - escalate_to_human → human lawyer must review before continuing
"""

from __future__ import annotations

from .base import BaseAgent
from ..state.contract_state import ContractState, Artifacts, Stage, ReviewDecision

SYSTEM_PROMPT = """\
You are a senior compliance officer reviewing the work of a legal analysis pipeline.
You will receive:
  1. The original contract text
  2. Parsed clauses and regulation matching results
  3. Risk assessment and consistency check results

Your job is to review the completeness and quality of the analysis.

## Review Checklist

### Completeness
- Are all clauses from the original document represented in the parsed output?
- Does every non_compliant / partially_compliant / uncertain clause have a regulation citation?
- Does the risk matrix cover all non_compliant items?

### Accuracy
- Are regulation citations correct and current?
- Are compliance judgments logically consistent with the cited regulations?
- Are there any contradictions between different agents' outputs?

### Coverage
- Are there obvious risks that were missed?
- Are there clauses with low-confidence judgments that need expert review?

## Output Format
Return a JSON object:
{
  "completeness": {
    "pass": true/false,
    "missing_clauses": ["clause descriptions that were not parsed"],
    "missing_citations": ["clause_ids with non_compliant judgment but no regulation reference"]
  },
  "accuracy": {
    "pass": true/false,
    "issues": [
      {"clause_id": "...", "description": "...", "suggestion": "..."}
    ]
  },
  "coverage": {
    "pass": true/false,
    "missed_risks": ["description of risks that should have been flagged"]
  },
  "decision": "pass | fix_and_retry | escalate_to_human",
  "fix_instructions": "specific instructions if decision is fix_and_retry",
  "escalation_reason": "reason if decision is escalate_to_human",
  "overall_assessment": "summary"
}

Decision logic:
- "pass": all checks pass, no critical or uncertain items remain
- "fix_and_retry": minor issues that can be fixed by re-running the parser/matcher
- "escalate_to_human": uncertain judgments on critical/high severity items,
  or regulation coverage gaps that cannot be resolved automatically
"""


class ComplianceReviewerAgent(BaseAgent):
    name = "ComplianceReviewer"

    def run(self, state: ContractState) -> ContractState:
        self._log_start(state)
        artifacts = state.artifacts

        clauses_text = "\n".join(
            f"- [{c.get('clause_id', '?')}] ({c.get('clause_type', '?')}) {c.get('content', '')[:150]}"
            for c in artifacts.clauses
        )

        compliance_text = "\n".join(
            f"- [{r.get('clause_id', '?')}] {r.get('regulation', '?')}: "
            f"{r.get('judgment', '?')} ({r.get('confidence', '?')}) — {r.get('reason', '')}"
            for r in artifacts.compliance_results
        )

        risk_text = "\n".join(
            f"- [{r.get('risk_id', '?')}] ({r.get('severity', '?')}/{r.get('probability', '?')}) "
            f"{r.get('description', '')} → {r.get('suggestion', '')}"
            for r in artifacts.risk_matrix
        ) or "No risks identified."

        consistency_text = "\n".join(
            f"- [{i.get('issue_type', '?')}] ({i.get('severity', '?')}) {i.get('description', '')}"
            for i in artifacts.consistency_results
        ) or "No consistency issues."

        user_prompt = (
            f"# Original Contract\n\n{artifacts.document_text[:3000]}...\n\n"
            f"# Parsed Clauses\n\n{clauses_text}\n\n"
            f"# Regulation Matching\n\n{compliance_text}\n\n"
            f"# Risk Matrix\n\n{risk_text}\n\n"
            f"# Consistency Check\n\n{consistency_text}\n\n"
            "Please perform your compliance review."
        )

        result = self.llm.chat_json(SYSTEM_PROMPT, user_prompt)

        # Build human-readable report
        report_lines = [
            "# Compliance Review Report\n",
            "## Completeness",
            f"**Pass:** {result.get('completeness', {}).get('pass', 'N/A')}\n",
        ]
        mc = result.get("completeness", {}).get("missing_clauses", [])
        if mc:
            report_lines.append(f"Missing clauses: {', '.join(mc)}")
        mic = result.get("completeness", {}).get("missing_citations", [])
        if mic:
            report_lines.append(f"Missing citations: {', '.join(mic)}")

        report_lines.append("\n## Accuracy")
        report_lines.append(f"**Pass:** {result.get('accuracy', {}).get('pass', 'N/A')}\n")
        for issue in result.get("accuracy", {}).get("issues", []):
            report_lines.append(
                f"- {issue.get('clause_id', '?')}: {issue.get('description', '')} → {issue.get('suggestion', '')}"
            )

        report_lines.append("\n## Coverage")
        report_lines.append(f"**Pass:** {result.get('coverage', {}).get('pass', 'N/A')}\n")
        for risk in result.get("coverage", {}).get("missed_risks", []):
            report_lines.append(f"- {risk}")

        report_lines.append(f"\n## Decision: **{result.get('decision', 'unknown')}**")
        if result.get("escalation_reason"):
            report_lines.append(f"## Escalation Reason\n{result['escalation_reason']}")
        report_lines.append(f"\n## Overall Assessment\n{result.get('overall_assessment', '')}")

        report_text = "\n".join(report_lines)

        # Map decision
        decision_str = result.get("decision", "fix_and_retry")
        try:
            decision = ReviewDecision(decision_str)
        except ValueError:
            decision = ReviewDecision.FIX_AND_RETRY

        new_artifacts = Artifacts(
            document_text=artifacts.document_text,
            clauses=artifacts.clauses,
            compliance_results=artifacts.compliance_results,
            consistency_results=artifacts.consistency_results,
            risk_matrix=artifacts.risk_matrix,
            review_report=report_text,
        )

        state.add_version(
            stage=Stage.COMPLIANCE_REVIEW,
            agent=self.name,
            artifacts=new_artifacts,
            metadata={
                "decision": decision.value,
                "fix_instructions": result.get("fix_instructions", ""),
                "escalation_reason": result.get("escalation_reason", ""),
            },
        )

        # Create escalation if needed
        if decision == ReviewDecision.ESCALATE_TO_HUMAN:
            state.add_escalation(
                reason=result.get("escalation_reason", "Compliance review flagged for human review"),
                severity="high",
                related=[],
            )

        self._log_done(state)
        return state
