"""
Risk Assessor Agent — evaluates compliance results and produces a risk matrix.

This agent receives the output from ParserMatcher (structured clauses + compliance
results) and the output from the rule-based ConsistencyChecker. It synthesises both
into a comprehensive risk assessment.
"""

from __future__ import annotations

from .base import BaseAgent
from ..state.contract_state import ContractState, Artifacts, Stage

SYSTEM_PROMPT = """\
You are a risk management consultant specialising in legal compliance.
You will receive:
  1. Structured contract clauses
  2. Regulation matching results (compliance judgments per clause)
  3. Rule-engine consistency check results (cross-clause issues)

Your job is to produce a comprehensive risk matrix.

## Risk Assessment Framework

For each risk, classify:
- risk_type: legal | commercial | operational | reputational
- severity: critical | high | medium | low
  - critical: could void the contract or trigger regulatory penalties
  - high: could result in significant financial loss or litigation
  - medium: could cause disputes or minor losses
  - low: non-standard but limited impact
- probability: high | medium | low
  - high: commonly seen in industry enforcement
  - medium: conditionally triggered
  - low: low probability but high impact
- description: clear explanation of the risk
- related_clauses: which clauses are involved
- suggestion: mitigation approach

## Cross-Clause Analysis (important)
The rule engine has already identified some consistency issues. For each issue:
- Validate whether it is a real risk or a false positive
- Assess its severity in the full contract context
- If you disagree with the rule engine, explain why

Also look for risks the rule engine cannot catch:
- Clauses that are individually compliant but collectively create an
  unfavourable structure (e.g., payment terms + penalty terms that
  effectively trap one party)
- Missing clauses that should be present for this contract type
- Vague language that could be interpreted against one party

## Output Format
Return a JSON object:
{
  "risk_matrix": [
    {
      "risk_id": "R01",
      "risk_type": "legal",
      "severity": "critical",
      "probability": "medium",
      "description": "...",
      "related_clauses": ["C03", "C07"],
      "suggestion": "..."
    }
  ],
  "consistency_validation": [
    {
      "original_issue": "...",
      "is_valid": true,
      "adjusted_severity": "high",
      "notes": "..."
    }
  ],
  "missing_clauses": [
    {"suggested_clause": "保密条款", "reason": "合同涉及商业秘密但未设保密条款"}
  ],
  "overall_risk_level": "critical|high|medium|low",
  "summary": "brief risk summary"
}
"""


class RiskAssessorAgent(BaseAgent):
    name = "RiskAssessor"

    def run(self, state: ContractState) -> ContractState:
        self._log_start(state)
        artifacts = state.artifacts

        clauses_text = "\n".join(
            f"- [{c.get('clause_id', '?')}] ({c.get('clause_type', '?')}) {c.get('content', '')[:120]}..."
            for c in artifacts.clauses
        )

        compliance_text = "\n".join(
            f"- [{r.get('clause_id', '?')}] {r.get('regulation', '?')}: "
            f"{r.get('judgment', '?')} (confidence: {r.get('confidence', '?')}) — {r.get('reason', '')}"
            for r in artifacts.compliance_results
        )

        consistency_text = "\n".join(
            f"- [{i.get('issue_type', '?')}] (severity: {i.get('severity', '?')}) "
            f"{i.get('description', '')} — clauses: {', '.join(i.get('related_clauses', []))}"
            for i in artifacts.consistency_results
        ) or "No consistency issues found by rule engine."

        user_prompt = (
            f"# Contract Type: {state.contract_type}\n\n"
            f"# Structured Clauses\n\n{clauses_text}\n\n"
            f"# Regulation Matching Results\n\n{compliance_text}\n\n"
            f"# Rule Engine Consistency Results\n\n{consistency_text}\n\n"
            "Please produce a comprehensive risk assessment."
        )

        result = self.llm.chat_json(SYSTEM_PROMPT, user_prompt)

        new_artifacts = Artifacts(
            document_text=artifacts.document_text,
            clauses=artifacts.clauses,
            compliance_results=artifacts.compliance_results,
            consistency_results=artifacts.consistency_results,
            risk_matrix=result.get("risk_matrix", []),
        )

        state.add_version(
            stage=Stage.RISK_ASSESSMENT,
            agent=self.name,
            artifacts=new_artifacts,
            metadata={
                "overall_risk_level": result.get("overall_risk_level", "unknown"),
                "missing_clauses": result.get("missing_clauses", []),
                "summary": result.get("summary", ""),
            },
        )

        self._log_done(state)
        return state
