"""Base class for all compliance pipeline agents."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod

from ..llm.client import LLMClient
from ..state.contract_state import ContractState

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    name: str = "BaseAgent"

    def __init__(self, llm: LLMClient):
        self.llm = llm

    @abstractmethod
    def run(self, state: ContractState) -> ContractState:
        ...

    def _log_start(self, state: ContractState) -> None:
        logger.info("=" * 60)
        logger.info("Agent [%s] starting — stage=%s  version=%d",
                     self.name, state.stage.value, state.current_version)
        logger.info("=" * 60)

    def _log_done(self, state: ContractState) -> None:
        logger.info("Agent [%s] done — new version=%d", self.name, state.current_version)
