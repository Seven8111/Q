"""Multi-Agent Legal Compliance Review System."""

__version__ = "0.1.0"
