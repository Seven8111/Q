"""
Versioned contract state management for the legal compliance pipeline.

Each agent appends a new version. Rollback is pointer-switching, not deletion.
Human escalations are tracked as a separate list.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any


class Stage(str, Enum):
    INIT = "init"
    PARSING_MATCHING = "parsing_matching"
    RISK_ASSESSMENT = "risk_assessment"
    COMPLIANCE_REVIEW = "compliance_review"
    ADVISORY = "advisory"
    DONE = "done"
    FAILED = "failed"
    ESCALATED = "escalated"


class ReviewDecision(str, Enum):
    PASS = "pass"
    FIX_AND_RETRY = "fix_and_retry"
    ESCALATE_TO_HUMAN = "escalate_to_human"


@dataclass
class Clause:
    """A single parsed contract clause."""

    clause_id: str
    clause_type: str  # e.g. payment, confidentiality, liability, termination
    parties: list[str] = field(default_factory=list)
    content: str = ""
    amount: str = ""
    date: str = ""
    obligations: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)  # IDs of related clauses


@dataclass
class ComplianceResult:
    """Regulation matching result for a single clause."""

    clause_id: str
    regulation: str  # e.g. "《民法典》第585条"
    judgment: str  # compliant, non_compliant, partially_compliant, uncertain, not_applicable
    confidence: str  # high, medium, low
    reason: str = ""
    regulation_text: str = ""  # excerpt of the matched regulation


@dataclass
class RiskItem:
    """A single identified risk."""

    risk_id: str
    risk_type: str  # legal, commercial, operational, reputational
    severity: str  # critical, high, medium, low
    probability: str  # high, medium, low
    description: str = ""
    related_clauses: list[str] = field(default_factory=list)
    suggestion: str = ""


@dataclass
class HumanEscalation:
    """An item that requires human review."""

    escalation_id: str
    reason: str
    severity: str
    related_items: list[str] = field(default_factory=list)
    resolved: bool = False
    resolution: str = ""


@dataclass
class Artifacts:
    """Holds all intermediate outputs."""

    document_text: str = ""
    clauses: list[dict] = field(default_factory=list)  # serialised Clause list
    compliance_results: list[dict] = field(default_factory=list)  # serialised ComplianceResult list
    risk_matrix: list[dict] = field(default_factory=list)  # serialised RiskItem list
    consistency_results: list[dict] = field(default_factory=list)  # from rule engine
    review_report: str = ""
    amendment_proposals: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Artifacts:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class Version:
    version: int
    stage: Stage
    agent: str
    timestamp: str
    artifacts: Artifacts
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["stage"] = self.stage.value
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Version:
        data = data.copy()
        data["stage"] = Stage(data["stage"])
        data["artifacts"] = Artifacts.from_dict(data.get("artifacts", {}))
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class ContractState:
    """
    Central state object shared across all agents in the compliance pipeline.
    """

    contract_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    current_version: int = 0
    versions: list[Version] = field(default_factory=list)
    rollback_count: int = 0
    max_rollbacks: int = 2
    human_escalations: list[dict] = field(default_factory=list)
    final_output: dict[str, Any] | None = None
    contract_type: str = ""  # e.g. labour, sales, service
    regulation_scope: list[str] = field(default_factory=list)  # injected regulations

    # ------------------------------------------------------------------
    # Version management
    # ------------------------------------------------------------------

    def add_version(
        self,
        stage: Stage,
        agent: str,
        artifacts: Artifacts,
        metadata: dict[str, Any] | None = None,
    ) -> Version:
        self.current_version += 1
        ver = Version(
            version=self.current_version,
            stage=stage,
            agent=agent,
            timestamp=datetime.now(timezone.utc).isoformat(),
            artifacts=artifacts,
            metadata=metadata or {},
        )
        self.versions.append(ver)
        return ver

    def latest(self) -> Version | None:
        return self.versions[-1] if self.versions else None

    def get_version(self, version: int) -> Version | None:
        for v in self.versions:
            if v.version == version:
                return v
        return None

    def rollback_to(self, version: int) -> Version | None:
        target = self.get_version(version)
        if target is None:
            return None
        self.current_version = version
        self.rollback_count += 1
        return target

    def can_rollback(self) -> bool:
        return self.rollback_count < self.max_rollbacks

    def add_escalation(self, reason: str, severity: str, related: list[str] | None = None) -> None:
        self.human_escalations.append({
            "id": uuid.uuid4().hex[:8],
            "reason": reason,
            "severity": severity,
            "related_items": related or [],
            "resolved": False,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    @property
    def stage(self) -> Stage:
        v = self.latest()
        return v.stage if v else Stage.INIT

    @property
    def artifacts(self) -> Artifacts:
        v = self.latest()
        return v.artifacts if v else Artifacts()

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return {
            "contract_id": self.contract_id,
            "current_version": self.current_version,
            "versions": [v.to_dict() for v in self.versions],
            "rollback_count": self.rollback_count,
            "max_rollbacks": self.max_rollbacks,
            "human_escalations": self.human_escalations,
            "final_output": self.final_output,
            "contract_type": self.contract_type,
            "regulation_scope": self.regulation_scope,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ContractState:
        state = cls(
            contract_id=data["contract_id"],
            current_version=data["current_version"],
            rollback_count=data.get("rollback_count", 0),
            max_rollbacks=data.get("max_rollbacks", 2),
            human_escalations=data.get("human_escalations", []),
            final_output=data.get("final_output"),
            contract_type=data.get("contract_type", ""),
            regulation_scope=data.get("regulation_scope", []),
        )
        state.versions = [Version.from_dict(v) for v in data.get("versions", [])]
        return state

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, ensure_ascii=False))

    @classmethod
    def load(cls, path: str | Path) -> ContractState:
        return cls.from_dict(json.loads(Path(path).read_text()))

    def summary(self) -> str:
        lines = [
            f"Contract: {self.contract_id}",
            f"Type:     {self.contract_type}",
            f"Stage:    {self.stage.value}",
            f"Version:  {self.current_version}",
            f"Rollbacks: {self.rollback_count}/{self.max_rollbacks}",
            f"Escalations: {len(self.human_escalations)}",
        ]
        for v in self.versions:
            lines.append(f"  v{v.version} [{v.stage.value}] by {v.agent} @ {v.timestamp[:19]}")
        return "\n".join(lines)
