"""
Rule-based consistency checker for cross-clause analysis.

This module replaces LLM-based cross-clause reasoning with deterministic
rules. LLM is good at understanding meaning, but unreliable at precise
numerical comparison across distant clauses. Rules handle that.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class ConsistencyIssue:
    issue_type: str  # amount_mismatch, term_conflict, obligation_imbalance, catch_all_risk
    severity: str  # critical, high, medium, low
    description: str
    related_clauses: list[str] = field(default_factory=list)
    details: str = ""


class ConsistencyChecker:
    """Deterministic cross-clause consistency checks."""

    def check(self, clauses: list[dict]) -> list[dict]:
        """Run all consistency checks and return a list of issues."""
        issues: list[ConsistencyIssue] = []

        issues.extend(self._check_amount_consistency(clauses))
        issues.extend(self._check_term_consistency(clauses))
        issues.extend(self._check_obligation_balance(clauses))
        issues.extend(self._check_catch_all_clauses(clauses))
        issues.extend(self._check_period_logic(clauses))

        return [
            {
                "issue_type": i.issue_type,
                "severity": i.severity,
                "description": i.description,
                "related_clauses": i.related_clauses,
                "details": i.details,
            }
            for i in issues
        ]

    # ------------------------------------------------------------------
    # Individual check methods
    # ------------------------------------------------------------------

    def _check_amount_consistency(self, clauses: list[dict]) -> list[ConsistencyIssue]:
        """Find all monetary amounts and flag inconsistencies."""
        issues: list[ConsistencyIssue] = []
        amounts: list[tuple[str, str, float]] = []  # (clause_id, context, value)

        for c in clauses:
            content = c.get("content", "")
            cid = c.get("clause_id", "?")
            ctype = c.get("clause_type", "")

            # Extract amounts with context
            # Pattern: Chinese yuan amounts like 10000元, ￥10,000, 人民币壹万元
            patterns = [
                r'(\d[\d,]*\.?\d*)\s*(?:元|万元|万元整)',
                r'[￥¥]\s*(\d[\d,]*\.?\d*)',
                r'人民币\s*(\d[\d,]*\.?\d*)',
            ]
            for pat in patterns:
                for m in re.finditer(pat, content):
                    raw = m.group(1).replace(",", "")
                    try:
                        val = float(raw)
                        if "万" in content[m.start():m.end() + 5]:
                            val *= 10000
                        amounts.append((cid, ctype, val))
                    except ValueError:
                        continue

        # Check: penalty/liquidated damages should not exceed principal
        payment_amounts = [(cid, v) for cid, ct, v in amounts if ct in ("payment", "price")]
        penalty_amounts = [(cid, v) for cid, ct, v in amounts if ct in ("penalty", "liquidated_damages")]

        for p_cid, p_val in payment_amounts:
            for q_cid, q_val in penalty_amounts:
                if q_val > p_val * 0.3:  # 30% threshold per common practice
                    issues.append(ConsistencyIssue(
                        issue_type="amount_mismatch",
                        severity="high",
                        description=(
                            f"违约金（{q_val:,.0f}元）占合同金额（{p_val:,.0f}元）的 "
                            f"{q_val / p_val * 100:.1f}%，超过30%的合理范围"
                        ),
                        related_clauses=[p_cid, q_cid],
                        details="根据司法实践，违约金超过实际损失30%通常被认为过高",
                    ))

        return issues

    def _check_term_consistency(self, clauses: list[dict]) -> list[ConsistencyIssue]:
        """Check for conflicting terms across clauses."""
        issues: list[ConsistencyIssue] = []
        terms: dict[str, list[tuple[str, str]]] = {}  # keyword → [(clause_id, content_snippet)]

        conflict_pairs = [
            ("不可抗力", "免责"),
            ("保密期限", "合同期限"),
            ("排他", "非排他"),
        ]

        for c in clauses:
            content = c.get("content", "")
            cid = c.get("clause_id", "?")
            for keyword, _ in conflict_pairs:
                if keyword in content:
                    terms.setdefault(keyword, []).append((cid, content[:100]))

        # Check: "exclusive" and "non-exclusive" in same contract
        if "排他" in terms and "非排他" in terms:
            issues.append(ConsistencyIssue(
                issue_type="term_conflict",
                severity="critical",
                description='合同中同时出现"排他"和"非排他"条款，存在根本性矛盾',
                related_clauses=[t[0] for t in terms.get("排他", [])] + [t[0] for t in terms.get("非排他", [])],
            ))

        return issues

    def _check_obligation_balance(self, clauses: list[dict]) -> list[ConsistencyIssue]:
        """Check if obligations are balanced between parties."""
        issues: list[ConsistencyIssue] = []
        party_obligations: dict[str, list[str]] = {}  # party → [clause_ids]

        for c in clauses:
            obligations = c.get("obligations", [])
            cid = c.get("clause_id", "?")
            for party in c.get("parties", []):
                party_obligations.setdefault(party, []).append(cid)

        if len(party_obligations) >= 2:
            parties = list(party_obligations.keys())
            counts = [len(party_obligations[p]) for p in parties]
            if max(counts) > 0 and min(counts) > 0:
                ratio = max(counts) / min(counts)
                if ratio > 3:
                    issues.append(ConsistencyIssue(
                        issue_type="obligation_imbalance",
                        severity="medium",
                        description=(
                            f"义务分配明显不对等：{parties[0]}有{counts[0]}项义务，"
                            f"{parties[1]}有{counts[1]}项义务"
                        ),
                        related_clauses=[cid for cids in party_obligations.values() for cid in cids[:3]],
                        details="单方面加重一方义务的条款可能被认定为格式条款",
                    ))

        return issues

    def _check_catch_all_clauses(self, clauses: list[dict]) -> list[ConsistencyIssue]:
        """Flag overly broad catch-all language."""
        issues: list[ConsistencyIssue] = []
        catch_all_patterns = [
            (r'包括但不限于', "including but not limited to"),
            (r'其他\s*(?:合理|合法|必要)', "other reasonable/legal/necessary"),
            (r'等\s*(?:相关|合理)', "etc. related/reasonable"),
            (r'甲方\s*(?:有权|可以)\s*(?:自行|单方)', "Party A may unilaterally"),
        ]

        for c in clauses:
            content = c.get("content", "")
            cid = c.get("clause_id", "?")
            for pat, desc in catch_all_patterns:
                if re.search(pat, content):
                    issues.append(ConsistencyIssue(
                        issue_type="catch_all_risk",
                        severity="medium",
                        description=f"条款使用了兜底性表述（{desc}），可能赋予一方过大裁量权",
                        related_clauses=[cid],
                        details=f"匹配内容: {content[:80]}...",
                    ))

        return issues

    def _check_period_logic(self, clauses: list[dict]) -> list[ConsistencyIssue]:
        """Check for logical conflicts in time periods."""
        issues: list[ConsistencyIssue] = []
        periods: list[tuple[str, str, int, str]] = []  # (clause_id, type, days, raw_text)

        period_patterns = [
            (r'(\d+)\s*(?:个?\s*)?天', 1),
            (r'(\d+)\s*个月', 30),
            (r'(\d+)\s*年', 365),
        ]

        for c in clauses:
            content = c.get("content", "")
            cid = c.get("clause_id", "?")
            ctype = c.get("clause_type", "")
            for pat, multiplier in period_patterns:
                for m in re.finditer(pat, content):
                    try:
                        days = int(m.group(1)) * multiplier
                        periods.append((cid, ctype, days, m.group(0)))
                    except ValueError:
                        continue

        # Check: warranty period should not exceed contract duration
        contract_periods = [(cid, d) for cid, ct, d, _ in periods if ct in ("duration", "term")]
        warranty_periods = [(cid, d) for cid, ct, d, _ in periods if ct in ("warranty", "guarantee")]

        for c_cid, c_days in contract_periods:
            for w_cid, w_days in warranty_periods:
                if w_days > c_days:
                    issues.append(ConsistencyIssue(
                        issue_type="term_conflict",
                        severity="high",
                        description=(
                            f"保修/保证期限（{w_days}天）超过合同期限（{c_days}天），"
                            f"保修期超出合同有效期"
                        ),
                        related_clauses=[c_cid, w_cid],
                    ))

        return issues
