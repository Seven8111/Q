#!/usr/bin/env python3
"""
Multi-Agent Legal Compliance Review System.

Usage:
    python main.py                                  # Run with example contract
    python main.py --contract contract.txt          # Run with custom contract
    python main.py --resume state.json              # Resume from saved state
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

from src.llm.client import LLMClient
from src.agents.parser_matcher import ParserMatcherAgent
from src.agents.risk_assessor import RiskAssessorAgent
from src.agents.compliance_reviewer import ComplianceReviewerAgent
from src.agents.advisor import AdvisorAgent
from src.rules.consistency import ConsistencyChecker
from src.scheduler.scheduler import Scheduler, Action
from src.state.contract_state import ContractState, Artifacts, Stage


def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    logging.basicConfig(level=level, format=fmt, stream=sys.stderr)


def on_step(action: Action, state: ContractState) -> None:
    v = state.latest()
    if v:
        print(f"  ✓ {action.value} completed → version {v.version}  [{v.stage.value}]")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Multi-Agent Legal Compliance Review System"
    )
    p.add_argument("--contract", "-c", type=str, help="Path to contract text file")
    p.add_argument("--text", "-t", type=str, help="Contract text directly")
    p.add_argument("--resume", type=str, help="Resume from saved state JSON")
    p.add_argument("--output", "-o", type=str, default="output", help="Output directory")
    p.add_argument("--model", type=str, default="gpt-4o", help="LLM model name")
    p.add_argument("--base-url", type=str, help="OpenAI-compatible API base URL")
    p.add_argument("--contract-type", type=str, default="",
                   help="Contract type hint (sales, labour, service, lease, technology)")
    p.add_argument("--regulations", type=str, nargs="*", default=[],
                   help="List of applicable regulations to focus on")
    p.add_argument("--max-rollbacks", type=int, default=2, help="Max rollbacks")
    p.add_argument("--verbose", "-v", action="store_true", help="Verbose logging")
    return p


def main() -> None:
    args = build_parser().parse_args()
    setup_logging(args.verbose)

    if args.resume:
        state = ContractState.load(args.resume)
        print(f"Resumed contract {state.contract_id} at version {state.current_version}")
    else:
        doc_text = ""
        if args.text:
            doc_text = args.text
        elif args.contract:
            doc_text = Path(args.contract).read_text(encoding="utf-8")
        else:
            example = Path(__file__).parent / "examples" / "example_contract.txt"
            if example.exists():
                doc_text = example.read_text(encoding="utf-8")
                print("No contract provided — using built-in example.\n")
            else:
                print("Error: provide --contract or --text", file=sys.stderr)
                sys.exit(1)

        state = ContractState(max_rollbacks=args.max_rollbacks)
        state.contract_type = args.contract_type
        state.regulation_scope = args.regulations or [
            "《民法典》合同编",
            "《劳动合同法》",
            "《消费者权益保护法》",
        ]
        state.add_version(
            stage=Stage.INIT,
            agent="user",
            artifacts=Artifacts(document_text=doc_text),
        )
        print(f"Contract ID: {state.contract_id}")
        print(f"Contract type: {state.contract_type or 'auto-detect'}")
        print(f"Regulation scope: {', '.join(state.regulation_scope)}")
        print(f"Document length: {len(doc_text)} chars\n")

    llm = LLMClient(model=args.model, base_url=args.base_url)

    parser_matcher = ParserMatcherAgent(llm)
    risk_assessor = RiskAssessorAgent(llm)
    reviewer = ComplianceReviewerAgent(llm)
    advisor = AdvisorAgent(llm)
    consistency = ConsistencyChecker()

    scheduler = Scheduler(parser_matcher, risk_assessor, reviewer, advisor, consistency)
    scheduler.on_step = on_step

    print("=" * 60)
    print("Starting compliance review pipeline...")
    print("=" * 60)

    result = scheduler.run(state)

    # ── Output ───────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    if result.escalated:
        print("Pipeline ESCALATED to human review")
    elif result.success:
        print("Pipeline SUCCEEDED")
    else:
        print("Pipeline FAILED")
    print(f"Versions: {result.total_versions}  Rollbacks: {result.rollbacks_used}")
    print(f"Message: {result.message}")
    print("=" * 60)

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    state_path = output_dir / "state.json"
    result.state.save(state_path)
    print(f"\nState saved to: {state_path}")

    artifacts = result.state.artifacts

    # Save review report
    if artifacts.review_report:
        (output_dir / "review_report.md").write_text(
            artifacts.review_report, encoding="utf-8"
        )
        print(f"  Review report: {output_dir / 'review_report.md'}")

    # Save risk matrix
    if artifacts.risk_matrix:
        (output_dir / "risk_matrix.json").write_text(
            json.dumps(artifacts.risk_matrix, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"  Risk matrix: {output_dir / 'risk_matrix.json'}")

    # Save compliance results
    if artifacts.compliance_results:
        (output_dir / "compliance_results.json").write_text(
            json.dumps(artifacts.compliance_results, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"  Compliance results: {output_dir / 'compliance_results.json'}")

    # Save amendment proposals
    if artifacts.amendment_proposals:
        (output_dir / "amendments.json").write_text(
            json.dumps(artifacts.amendment_proposals, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"  Amendment proposals: {output_dir / 'amendments.json'}")

    # Save parsed clauses
    if artifacts.clauses:
        (output_dir / "clauses.json").write_text(
            json.dumps(artifacts.clauses, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"  Parsed clauses: {output_dir / 'clauses.json'}")

    # Save escalations
    if result.state.human_escalations:
        (output_dir / "escalations.json").write_text(
            json.dumps(result.state.human_escalations, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"  Human escalations: {output_dir / 'escalations.json'}")

    print(f"\nAll outputs saved to: {output_dir}/")
    print("\n" + result.state.summary())

    sys.exit(0 if result.success else (2 if result.escalated else 1))


if __name__ == "__main__":
    main()
